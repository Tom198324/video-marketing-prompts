# Prompts Vidéo Marketing - Collection Professionnelle

<div align="center">

[![npm version](https://img.shields.io/npm/v/@prompts-video-marketing/sdk?style=flat-square&logo=npm&color=CB3837)](https://www.npmjs.com/package/@prompts-video-marketing/sdk)
[![npm downloads](https://img.shields.io/npm/dm/@prompts-video-marketing/sdk?style=flat-square&logo=npm&color=CB3837)](https://www.npmjs.com/package/@prompts-video-marketing/sdk)
[![PyPI version](https://img.shields.io/pypi/v/prompts-video-marketing?style=flat-square&logo=pypi&color=3776AB)](https://pypi.org/project/prompts-video-marketing/)
[![PyPI downloads](https://img.shields.io/pypi/dm/prompts-video-marketing?style=flat-square&logo=pypi&color=3776AB)](https://pypi.org/project/prompts-video-marketing/)
[![Python versions](https://img.shields.io/pypi/pyversions/prompts-video-marketing?style=flat-square&logo=python&color=3776AB)](https://pypi.org/project/prompts-video-marketing/)

[![Build Status](https://img.shields.io/github/actions/workflow/status/votre-org/prompts-video-marketing/ci.yml?style=flat-square&logo=github)](https://github.com/votre-org/prompts-video-marketing/actions)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-3178C6?style=flat-square&logo=typescript)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/github/license/votre-org/prompts-video-marketing?style=flat-square&color=green)](./LICENSE)
[![Documentation](https://img.shields.io/badge/docs-available-brightgreen?style=flat-square&logo=readthedocs)](https://votre-site.manus.space/documentation)

[![Stars](https://img.shields.io/github/stars/votre-org/prompts-video-marketing?style=flat-square&logo=github)](https://github.com/votre-org/prompts-video-marketing/stargazers)
[![Issues](https://img.shields.io/github/issues/votre-org/prompts-video-marketing?style=flat-square&logo=github)](https://github.com/votre-org/prompts-video-marketing/issues)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen?style=flat-square)](https://github.com/votre-org/prompts-video-marketing/pulls)

**🇫🇷 Version française** | **[🇬🇧 English version](./README.en.md)**

</div>

---

Une collection complète de 50 prompts JSON professionnels pour générer des vidéos marketing de 20 secondes avec **Sora 2**, **Veo 3** et **Runway Gen-3**.

## 🎯 Fonctionnalités

### 📚 Collection de 50 Prompts Professionnels

- **50 prompts JSON** structurés et prêts à l'emploi
- **28 catégories** marketing (Product Launch, Brand Story, Tutorial, etc.)
- **24 styles** cinématographiques différents
- **20 secondes** de durée optimisée pour les réseaux sociaux

### 🎨 Générateur de Variations IA

Générez automatiquement des variations de prompts avec l'intelligence artificielle :

- **8 paramètres modifiables** : personnage, lieu, style cinématographique, équipement, éclairage, actions, audio, spécifications techniques
- **Génération par lot** : créez 1 à 5 variations en une seule requête
- **Navigation intuitive** : comparez les variations côte à côte avec le prompt original
- **Export facile** : copiez ou téléchargez les prompts générés

### 📦 SDK Officiels

Intégrez l'API dans vos applications avec nos SDK officiels :

#### JavaScript/TypeScript SDK

```bash
npm install @prompts-video-marketing/sdk
```

```typescript
import { PromptsVideoMarketingClient } from '@prompts-video-marketing/sdk';

const client = new PromptsVideoMarketingClient({
  baseURL: 'https://votre-site.manus.space',
});

const result = await client.generateVariation({
  promptId: 1,
  variations: { subject: true, location: true },
  count: 3,
});
```

**Fonctionnalités** :
- Types TypeScript complets
- Retry logic automatique avec backoff exponentiel
- Gestion des erreurs et timeouts
- 4 méthodes : `generateVariation`, `getPrompts`, `getPromptById`, `getPromptsByCategory`

📖 [Documentation complète JavaScript/TypeScript](./sdk/javascript/README.md)

#### Python SDK

```bash
pip install prompts-video-marketing
```

```python
from prompts_video_marketing import PromptsVideoMarketingClient

with PromptsVideoMarketingClient(
    base_url="https://votre-site.manus.space"
) as client:
    result = client.generate_variation({
        "prompt_id": 1,
        "variations": {"subject": True, "location": True},
        "count": 3,
    })
```

**Fonctionnalités** :
- Type hints Python complets
- Support context manager
- Retry logic avec backoff exponentiel
- Exemples async et variables d'environnement

📖 [Documentation complète Python](./sdk/python/README.md)

### 🔌 API LLM Intégrée

Utilisez l'API LLM pour générer des variations intelligentes :

- **Modèles IA** : Accès aux meilleurs modèles de langage
- **JSON Schema strict** : Garantit la validité des prompts générés
- **Multi-langages** : Exemples de code en cURL, Python, JavaScript, Go, PHP, Ruby
- **Intégrations tierces** : Utilisez l'API depuis n'importe quelle application

📖 [Documentation API LLM complète](https://votre-site.manus.space/documentation)

## 🚀 Démarrage rapide

### 1. Explorer les prompts

Parcourez la collection de 50 prompts professionnels organisés par catégorie :

```
https://votre-site.manus.space/explorer
```

### 2. Télécharger l'archive ZIP

Téléchargez la collection complète avec :
- 50 fichiers JSON individuels (prompt_01.json à prompt_50.json)
- Index CSV détaillé avec 9 colonnes
- README complet avec documentation

```
https://votre-site.manus.space/ → Télécharger ZIP v4.0 (212 KB)
```

### 3. Générer des variations

Utilisez le générateur IA pour créer des variations personnalisées :

```
https://votre-site.manus.space/generator
```

## 📁 Structure du projet

```
prompts-video-marketing/
├── client/                    # Application React frontend
│   ├── src/
│   │   ├── pages/            # Pages (Home, Explorer, Generator, Documentation)
│   │   ├── components/       # Composants réutilisables
│   │   └── lib/              # Configuration tRPC
├── server/                    # Backend Express + tRPC
│   ├── routers.ts            # Procédures tRPC (prompts, generator)
│   ├── db.ts                 # Helpers base de données
│   └── _core/                # LLM, auth, storage
├── sdk/                       # SDK officiels
│   ├── javascript/           # SDK npm TypeScript
│   └── python/               # SDK PyPI Python
├── drizzle/                   # Schéma base de données
└── prompts_package_v4/       # Collection de prompts
    ├── prompts/              # 50 fichiers JSON
    ├── index.csv             # Index détaillé
    └── README.md             # Documentation
```

## 🛠️ Technologies utilisées

### Frontend
- **React 19** avec TypeScript
- **Tailwind CSS 4** pour le design
- **tRPC** pour l'API type-safe
- **Wouter** pour le routing
- **Sonner** pour les notifications

### Backend
- **Express 4** avec TypeScript
- **tRPC 11** pour les procédures
- **Drizzle ORM** pour la base de données
- **API LLM intégrée** pour la génération IA

### SDK
- **TypeScript** avec types stricts
- **Python** avec type hints
- **Retry logic** automatique
- **Documentation** complète

## 📖 Documentation

### Guides utilisateur

- [Structure des prompts JSON](https://votre-site.manus.space/documentation) - Format et sections
- [Guide Sora 2](https://votre-site.manus.space/documentation) - Optimisation pour OpenAI Sora
- [Guide Veo 3](https://votre-site.manus.space/documentation) - Optimisation pour Google Veo
- [Guide Runway Gen-3](https://votre-site.manus.space/documentation) - Optimisation pour Runway
- [Personnalisation](https://votre-site.manus.space/documentation) - Adapter les prompts

### Documentation développeur

- [API LLM](https://votre-site.manus.space/documentation) - Intégration et exemples
- [SDK JavaScript/TypeScript](./sdk/javascript/README.md) - Installation et usage
- [SDK Python](./sdk/python/README.md) - Installation et usage
- [Endpoints tRPC](./server/routers.ts) - API backend

## 🎨 Exemples d'utilisation

### Générer 3 variations avec JavaScript

```javascript
const client = new PromptsVideoMarketingClient({
  baseURL: 'https://votre-site.manus.space',
});

const result = await client.generateVariation({
  promptId: 1,
  variations: {
    subject: true,
    location: true,
    style: true,
  },
  count: 3,
});

result.variations.forEach((variation, index) => {
  console.log(`Variation ${index + 1}:`);
  console.log('Personnage:', variation.data.subject.identity);
  console.log('Lieu:', variation.data.scene.location);
  console.log('Style:', variation.data.shot.camera_movement);
});
```

### Générer des variations avec Python

```python
from prompts_video_marketing import PromptsVideoMarketingClient

with PromptsVideoMarketingClient(
    base_url="https://votre-site.manus.space"
) as client:
    result = client.generate_variation({
        "prompt_id": 1,
        "variations": {
            "subject": True,
            "location": True,
            "style": True,
        },
        "count": 3,
    })
    
    for i, variation in enumerate(result["variations"], 1):
        print(f"Variation {i}:")
        print(f"Personnage: {variation['data']['subject']['identity']}")
        print(f"Lieu: {variation['data']['scene']['location']}")
```

## 🔐 Authentification

Les SDK supportent l'authentification par clé API :

```typescript
// JavaScript/TypeScript
const client = new PromptsVideoMarketingClient({
  baseURL: 'https://votre-site.manus.space',
  apiKey: 'votre-cle-api',
});
```

```python
# Python
client = PromptsVideoMarketingClient(
    base_url="https://votre-site.manus.space",
    api_key="votre-cle-api",
)
```

## 🤝 Contribution

Les contributions sont les bienvenues ! Pour contribuer :

1. Fork le projet
2. Créez une branche (`git checkout -b feature/AmazingFeature`)
3. Committez vos changements (`git commit -m 'Add AmazingFeature'`)
4. Pushez vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

## 📄 Licence

MIT

## 🆘 Support

Pour toute question ou problème :

- 📖 Consultez la [documentation complète](https://votre-site.manus.space/documentation)
- 💬 Ouvrez une [issue GitHub](https://github.com/votre-org/prompts-video-marketing/issues)
- 📧 Contactez-nous à contact@prompts-video-marketing.com

## 🎯 Roadmap

### Fonctionnalités à venir

- [ ] **Webhooks pour génération asynchrone** - Recevez des notifications quand la génération est terminée
- [ ] **Système d'authentification par API key** - Gérez vos clés API avec quotas et statistiques
- [ ] **Historique des variations** - Sauvegardez et consultez vos variations générées
- [ ] **Système de favoris** - Marquez vos prompts préférés
- [ ] **Export personnalisé** - Créez des exports sur mesure (JSON, CSV, PDF)

---

**Créé avec ❤️ pour les créateurs de contenu vidéo**
