# TODO - Restructuration Archive ZIP v4.0

## Tâches

### Phase 1 : Fichiers JSON Individuels
- [x] Créer un répertoire pour les 50 fichiers JSON individuels
- [x] Exporter chaque prompt dans son propre fichier JSON
- [x] Nommer les fichiers de manière cohérente (prompt_01.json, prompt_02.json, etc.)

### Phase 2 : Index CSV Détaillé
- [x] Créer un index CSV avec 9 colonnes (8 sections + JSON complet)
- [x] Extraire les informations clés de chaque section
- [x] Ajouter la colonne avec le JSON complet

### Phase 3 : README Complet
- [x] Rédiger une explication complète du projet
- [x] Documenter la structure des fichiers
- [x] Ajouter des exemples d'utilisation
- [x] Inclure les statistiques du projet

### Phase 4 : Archive ZIP et Mise à Jour
- [x] Créer l'archive ZIP v4.0
- [x] Copier dans client/public/
- [x] Mettre à jour le lien de téléchargement
- [x] Tester le téléchargement

## Générateur de Variations de Prompts

### Backend
- [x] Créer la procédure tRPC generateVariation avec intégration LLM
- [x] Implémenter la logique de génération de variations (personnage, lieu, style, équipement, éclairage, action, audio, technique)
- [x] Valider la structure JSON des prompts générés avec JSON Schema strict
- [x] Gérer les erreurs et timeouts de l'API LLM

### Frontend
- [x] Créer la page /generator pour le générateur de variations
- [x] Ajouter un sélecteur de prompt source avec support du paramètre URL
- [x] Créer les contrôles de variation (personnage, lieu, style, équipement, éclairage, action, audio, technique)
- [x] Afficher le prompt original et le prompt généré côte à côte
- [x] Ajouter un bouton pour copier ou télécharger le prompt généré
- [x] Implémenter les états de chargement et les messages d'erreur avec toast

### Navigation
- [x] Ajouter le lien "Générateur" dans le header
- [x] Ajouter un bouton "Générer une variation" sur les pages de détail des prompts

### Tests et Documentation
- [x] Tester la génération de variations avec différents prompts
- [x] Vérifier la qualité des variations générées
- [x] Créer des tests unitaires vitest pour le générateur
- [x] Créer un checkpoint final

## Génération par Lot de Variations

### Backend
- [x] Modifier la procédure generateVariation pour accepter un paramètre count (nombre de variations 1-5)
- [x] Générer plusieurs variations séquentiellement avec instructions différenciées
- [x] Retourner un tableau de variations avec identifiants uniques

### Frontend
- [x] Ajouter un sélecteur de nombre de variations (1-5)
- [x] Adapter l'affichage pour montrer plusieurs variations avec navigation
- [x] Ajouter des contrôles pour naviguer entre les variations (précédente/suivante + indicateurs)
- [x] Permettre de comparer les variations côte à côte avec le prompt original
- [x] Ajouter des boutons individuels pour copier/télécharger chaque variation

### Tests
- [x] Tester la génération de 3 variations simultanées
- [x] Vérifier que chaque variation est unique
- [x] Tester la navigation entre les variations
- [x] Mettre à jour les tests unitaires pour la génération par lot
- [x] Créer un checkpoint final

## Documentation API LLM

### Contenu à ajouter
- [x] Section "API LLM intégrée" dans la page Documentation
- [x] Explication du rôle et des fonctionnalités de l'API LLM
- [x] Description du fonctionnement technique (invokeLLM, messages, response_format)
- [x] Exemples de code pour utilisation côté serveur
- [x] Guide d'intégration pour applications tierces
- [x] Exemples d'endpoints tRPC personnalisés
- [x] Exemples d'appels HTTP depuis applications externes (cURL, Python)
- [x] Section sécurité et bonnes pratiques
- [x] Créer un checkpoint final

## Exemples Multi-Langages pour API LLM

### Langages à ajouter
- [x] Ajouter exemple JavaScript/Node.js (fetch, axios)
- [x] Ajouter exemple Go (net/http)
- [x] Ajouter exemple PHP (cURL)
- [x] Ajouter exemple Ruby (Net::HTTP)
- [x] Organiser les exemples avec des sections claires numérotées
- [x] Créer un checkpoint final

## SDK Officiels

### SDK npm (JavaScript/TypeScript)
- [x] Créer le package npm dans un dossier sdk/javascript
- [x] Définir les types TypeScript pour toutes les méthodes
- [x] Implémenter la classe client avec méthodes (generateVariation, getPrompts, getPromptById, getPromptsByCategory)
- [x] Ajouter la gestion automatique des erreurs avec retry logic et backoff exponentiel
- [x] Créer le fichier README.md avec exemples d'utilisation complets
- [x] Configurer le build TypeScript (tsconfig.json, package.json)

### SDK PyPI (Python)
- [x] Créer le package Python dans un dossier sdk/python
- [x] Définir les classes et types avec type hints complets
- [x] Implémenter le client Python avec support context manager
- [x] Ajouter retry logic avec backoff exponentiel (2s, 4s, 8s)
- [x] Créer le fichier README.md avec exemples complets (async, context manager, env vars)
- [x] Configurer setup.py pour publication PyPI

## Webhooks pour Génération Asynchrone

### Backend
- [ ] Créer la table webhooks dans le schéma de base de données
- [ ] Ajouter la procédure tRPC pour configurer les webhooks
- [ ] Modifier generateVariation pour supporter le mode asynchrone
- [ ] Implémenter l'envoi de webhooks POST avec retry
- [ ] Créer un système de logs pour les webhooks envoyés

### Frontend
- [ ] Créer la page de configuration des webhooks
- [ ] Ajouter l'interface pour tester les webhooks
- [ ] Afficher l'historique des webhooks envoyés

## Système d'Authentification par API Key

### Backend
- [ ] Créer la table api_keys dans le schéma
- [ ] Implémenter la génération de clés API sécurisées
- [ ] Créer le middleware de validation des clés API
- [ ] Implémenter le système de quotas (requêtes par jour/mois)
- [ ] Ajouter les procédures tRPC pour gérer les clés

### Frontend
- [ ] Créer la page de gestion des clés API
- [ ] Afficher les statistiques d'utilisation par clé
- [ ] Permettre la révocation et régénération des clés

### Tests et Documentation
- [ ] Créer des tests unitaires pour chaque fonctionnalité
- [ ] Mettre à jour la documentation avec les nouvelles features
- [ ] Créer un checkpoint final

## Mise à jour du README principal

- [x] Mettre à jour le README.md avec les informations sur les SDK officiels
- [x] Ajouter la documentation des fonctionnalités (générateur, SDK, API LLM)
- [x] Inclure les liens vers les SDK JavaScript et Python
- [x] Ajouter des exemples de code complets
- [x] Créer un checkpoint final

## Badges de statut pour README

- [x] Ajouter les badges npm (version, downloads, license)
- [x] Ajouter les badges PyPI (version, downloads, Python versions)
- [x] Ajouter les badges de build status, TypeScript, et documentation
- [x] Ajouter les badges GitHub (stars, issues, PRs welcome)
- [x] Créer un checkpoint final

## Version anglaise du README

- [x] Créer README.en.md avec traduction complète
- [x] Traduire toutes les sections (fonctionnalités, SDK, exemples, etc.)
- [x] Ajouter les mêmes badges de statut
- [x] Ajouter des liens de navigation FR ↔ EN dans les deux fichiers
- [x] Créer un checkpoint final

**Note** : Les deux versions (README.md et README.en.md) doivent être maintenues synchronisées lors de toute mise à jour future.

## Archive complète du projet

- [ ] Créer une archive ZIP complète avec tous les fichiers sources
- [ ] Inclure la documentation (README.md, README.en.md)
- [ ] Inclure les SDK (JavaScript et Python)
- [ ] Inclure le schéma de base de données (drizzle/schema.ts)
- [ ] Inclure la collection de prompts (prompts_package_v4)
- [ ] Copier l'archive dans client/public pour téléchargement
- [ ] Créer un checkpoint final
