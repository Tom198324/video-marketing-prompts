# Prompts Vidéo Marketing SDK (Python)

SDK officiel pour l'API Prompts Vidéo Marketing. Générez automatiquement des variations de prompts vidéo pour Sora 2, Veo 3 et Runway Gen-3 avec l'intelligence artificielle.

## 📦 Installation

```bash
pip install prompts-video-marketing
```

## 🚀 Démarrage rapide

```python
from prompts_video_marketing import PromptsVideoMarketingClient

# Créer une instance du client
client = PromptsVideoMarketingClient(
    base_url="https://votre-site.manus.space",
    api_key="votre-cle-api",  # Optionnel
    timeout=30,  # 30 secondes (défaut)
    retries=3,  # Nombre de tentatives (défaut)
)

# Générer des variations d'un prompt
result = client.generate_variation({
    "prompt_id": 1,
    "variations": {
        "subject": True,
        "location": True,
        "style": True,
    },
    "count": 3,  # Générer 3 variations
})

print(f"Généré {len(result['variations'])} variations !")
for i, variation in enumerate(result["variations"], 1):
    print(f"Variation {i}:", variation["data"])
```

## 📚 Documentation

### Configuration du client

```python
client = PromptsVideoMarketingClient(
    base_url="https://votre-site.manus.space",  # URL de base de l'API
    api_key="votre-cle-api",  # Clé API (optionnel)
    timeout=30,  # Timeout en secondes (défaut: 30)
    retries=3,  # Nombre de tentatives (défaut: 3)
)
```

### Méthodes disponibles

#### `generate_variation(options)`

Génère des variations d'un prompt existant.

```python
result = client.generate_variation({
    "prompt_id": 1,
    "variations": {
        "subject": True,      # Modifier le personnage
        "location": True,     # Modifier le lieu
        "style": True,        # Modifier le style cinématographique
        "equipment": False,   # Ne pas modifier l'équipement
        "lighting": False,    # Ne pas modifier l'éclairage
        "action": False,      # Ne pas modifier les actions
        "audio": False,       # Ne pas modifier l'audio
        "technical": False,   # Ne pas modifier les specs techniques
    },
    "count": 3,  # Générer 3 variations (1-5)
})
```

#### `get_prompts()`

Récupère la liste de tous les prompts disponibles.

```python
result = client.get_prompts()
print(f"{result['total']} prompts disponibles")
for prompt in result["prompts"]:
    print(f"- {prompt['title']} ({prompt['category']})")
```

#### `get_prompt_by_id(id)`

Récupère un prompt spécifique par son ID.

```python
prompt = client.get_prompt_by_id(1)
print(prompt["title"])
print(json.loads(prompt["prompt_json"]))
```

#### `get_prompts_by_category(category)`

Recherche des prompts par catégorie.

```python
result = client.get_prompts_by_category("Product Launch")
print(f"{len(result['prompts'])} prompts dans cette catégorie")
```

## 🔄 Gestion automatique des erreurs

Le SDK inclut une gestion automatique des erreurs avec **retry logic** :

- **Backoff exponentiel** : Délai croissant entre les tentatives (2s, 4s, 8s...)
- **Retry automatique** : Sur timeout, erreurs réseau, ou erreurs serveur 5xx
- **Timeout configurable** : Définissez votre propre timeout

```python
from prompts_video_marketing import APIError

try:
    result = client.generate_variation({
        "prompt_id": 1,
        "variations": {"subject": True},
    })
except APIError as e:
    print(f"Erreur après 3 tentatives: [{e.code}] {e.message}")
except Exception as e:
    print(f"Erreur réseau: {e}")
```

## 📝 Types et Type Hints

Le SDK est entièrement typé avec des type hints Python :

```python
from prompts_video_marketing import (
    VariationParams,
    GenerateVariationOptions,
    PromptData,
    GeneratedVariation,
    GenerateVariationResult,
    Prompt,
    PromptsListResult,
    APIError,
)
```

## 🌐 Exemples d'utilisation

### Context Manager

```python
with PromptsVideoMarketingClient(
    base_url="https://votre-site.manus.space"
) as client:
    result = client.generate_variation({
        "prompt_id": 1,
        "variations": {"subject": True, "location": True},
        "count": 2,
    })
    print(result)
# La session est automatiquement fermée
```

### Génération par lot

```python
# Générer 5 variations en une seule requête
result = client.generate_variation({
    "prompt_id": 1,
    "variations": {
        "subject": True,
        "location": True,
        "style": True,
    },
    "count": 5,
})

# Parcourir toutes les variations
for i, variation in enumerate(result["variations"], 1):
    data = variation["data"]
    print(f"\n=== Variation {i} ===")
    print(f"Personnage: {data['subject']['identity']}")
    print(f"Lieu: {data['scene']['location']}")
    print(f"Style: {data['shot']['camera_movement']}")
```

### Script asynchrone

```python
import asyncio
from concurrent.futures import ThreadPoolExecutor

async def generate_multiple_variations():
    """Génère des variations pour plusieurs prompts en parallèle."""
    client = PromptsVideoMarketingClient(
        base_url="https://votre-site.manus.space"
    )
    
    prompt_ids = [1, 2, 3, 4, 5]
    
    with ThreadPoolExecutor(max_workers=3) as executor:
        loop = asyncio.get_event_loop()
        tasks = [
            loop.run_in_executor(
                executor,
                client.generate_variation,
                {"prompt_id": pid, "variations": {"subject": True}, "count": 2}
            )
            for pid in prompt_ids
        ]
        results = await asyncio.gather(*tasks)
    
    client.close()
    return results

# Exécuter
results = asyncio.run(generate_multiple_variations())
print(f"Généré {len(results)} lots de variations")
```

### Utilisation avec variables d'environnement

```python
import os
from prompts_video_marketing import PromptsVideoMarketingClient

client = PromptsVideoMarketingClient(
    base_url=os.getenv("PROMPTS_API_URL"),
    api_key=os.getenv("PROMPTS_API_KEY"),
)

result = client.generate_variation({
    "prompt_id": 1,
    "variations": {"subject": True},
})
```

## 🔒 Authentification

Si votre API nécessite une authentification, fournissez votre clé API :

```python
client = PromptsVideoMarketingClient(
    base_url="https://votre-site.manus.space",
    api_key="votre-cle-api-secrete",
)
```

La clé sera automatiquement ajoutée dans l'en-tête `Authorization: Bearer <apiKey>`.

## 🧪 Tests

```bash
# Installer les dépendances de développement
pip install -e ".[dev]"

# Exécuter les tests
pytest

# Vérifier les types
mypy prompts_video_marketing

# Formater le code
black prompts_video_marketing
```

## 📄 Licence

MIT

## 🤝 Support

Pour toute question ou problème, consultez la documentation complète sur [votre-site.manus.space/documentation](https://votre-site.manus.space/documentation).
