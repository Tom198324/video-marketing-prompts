# Prompts Vidéo Marketing SDK (JavaScript/TypeScript)

SDK officiel pour l'API Prompts Vidéo Marketing. Générez automatiquement des variations de prompts vidéo pour Sora 2, Veo 3 et Runway Gen-3 avec l'intelligence artificielle.

## 📦 Installation

```bash
npm install @prompts-video-marketing/sdk
# ou
yarn add @prompts-video-marketing/sdk
# ou
pnpm add @prompts-video-marketing/sdk
```

## 🚀 Démarrage rapide

```typescript
import { PromptsVideoMarketingClient } from '@prompts-video-marketing/sdk';

// Créer une instance du client
const client = new PromptsVideoMarketingClient({
  baseURL: 'https://votre-site.manus.space',
  apiKey: 'votre-cle-api', // Optionnel
  timeout: 30000, // 30 secondes (défaut)
  retries: 3, // Nombre de tentatives (défaut)
});

// Générer des variations d'un prompt
const result = await client.generateVariation({
  promptId: 1,
  variations: {
    subject: true,
    location: true,
    style: true,
  },
  count: 3, // Générer 3 variations
});

console.log(`Généré ${result.variations.length} variations !`);
result.variations.forEach((variation, index) => {
  console.log(`Variation ${index + 1}:`, variation.data);
});
```

## 📚 Documentation

### Configuration du client

```typescript
interface SDKConfig {
  baseURL: string;        // URL de base de l'API
  apiKey?: string;        // Clé API (optionnel)
  timeout?: number;       // Timeout en ms (défaut: 30000)
  retries?: number;       // Nombre de tentatives (défaut: 3)
}
```

### Méthodes disponibles

#### `generateVariation(options)`

Génère des variations d'un prompt existant.

```typescript
const result = await client.generateVariation({
  promptId: 1,
  variations: {
    subject: true,      // Modifier le personnage
    location: true,     // Modifier le lieu
    style: true,        // Modifier le style cinématographique
    equipment: false,   // Ne pas modifier l'équipement
    lighting: false,    // Ne pas modifier l'éclairage
    action: false,      // Ne pas modifier les actions
    audio: false,       // Ne pas modifier l'audio
    technical: false,   // Ne pas modifier les specs techniques
  },
  count: 3, // Générer 3 variations (1-5)
});
```

#### `getPrompts()`

Récupère la liste de tous les prompts disponibles.

```typescript
const { prompts, total } = await client.getPrompts();
console.log(`${total} prompts disponibles`);
```

#### `getPromptById(id)`

Récupère un prompt spécifique par son ID.

```typescript
const prompt = await client.getPromptById(1);
console.log(prompt.title);
console.log(JSON.parse(prompt.promptJson));
```

#### `getPromptsByCategory(category)`

Recherche des prompts par catégorie.

```typescript
const { prompts } = await client.getPromptsByCategory('Product Launch');
console.log(`${prompts.length} prompts dans cette catégorie`);
```

## 🔄 Gestion automatique des erreurs

Le SDK inclut une gestion automatique des erreurs avec **retry logic** :

- **Backoff exponentiel** : Délai croissant entre les tentatives (1s, 2s, 4s...)
- **Retry automatique** : Sur timeout, erreurs réseau, ou erreurs serveur 5xx
- **Timeout configurable** : Définissez votre propre timeout

```typescript
try {
  const result = await client.generateVariation({
    promptId: 1,
    variations: { subject: true },
  });
} catch (error) {
  console.error('Erreur après 3 tentatives:', error.message);
}
```

## 📝 Types TypeScript

Le SDK est entièrement typé avec TypeScript. Tous les types sont exportés :

```typescript
import type {
  SDKConfig,
  VariationParams,
  GenerateVariationOptions,
  PromptData,
  GeneratedVariation,
  GenerateVariationResult,
  Prompt,
  PromptsListResult,
  APIError,
} from '@prompts-video-marketing/sdk';
```

## 🌐 Exemples d'utilisation

### Node.js (CommonJS)

```javascript
const { PromptsVideoMarketingClient } = require('@prompts-video-marketing/sdk');

const client = new PromptsVideoMarketingClient({
  baseURL: 'https://votre-site.manus.space',
});

async function main() {
  const result = await client.generateVariation({
    promptId: 1,
    variations: { subject: true, location: true },
    count: 2,
  });
  
  console.log(result);
}

main();
```

### TypeScript (ESM)

```typescript
import { PromptsVideoMarketingClient } from '@prompts-video-marketing/sdk';

const client = new PromptsVideoMarketingClient({
  baseURL: 'https://votre-site.manus.space',
  apiKey: process.env.API_KEY,
});

const result = await client.generateVariation({
  promptId: 1,
  variations: { subject: true },
});
```

### Génération par lot

```typescript
// Générer 5 variations en une seule requête
const result = await client.generateVariation({
  promptId: 1,
  variations: {
    subject: true,
    location: true,
    style: true,
  },
  count: 5,
});

// Parcourir toutes les variations
result.variations.forEach((variation, index) => {
  console.log(`\n=== Variation ${index + 1} ===`);
  console.log('Personnage:', variation.data.subject.identity);
  console.log('Lieu:', variation.data.scene.location);
  console.log('Style:', variation.data.shot.camera_movement);
});
```

## 🔒 Authentification

Si votre API nécessite une authentification, fournissez votre clé API :

```typescript
const client = new PromptsVideoMarketingClient({
  baseURL: 'https://votre-site.manus.space',
  apiKey: 'votre-cle-api-secrete',
});
```

La clé sera automatiquement ajoutée dans l'en-tête `Authorization: Bearer <apiKey>`.

## 📄 Licence

MIT

## 🤝 Support

Pour toute question ou problème, consultez la documentation complète sur [votre-site.manus.space/documentation](https://votre-site.manus.space/documentation).
