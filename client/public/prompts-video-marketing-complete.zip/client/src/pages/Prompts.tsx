import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Download, Film, Search } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

export default function Prompts() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSector, setSelectedSector] = useState<string>("all");
  const [selectedStyle, setSelectedStyle] = useState<string>("all");

  const { data: prompts, isLoading } = trpc.prompts.list.useQuery();
  const { data: stats } = trpc.prompts.getStats.useQuery();

  // Filtrer les prompts
  const filteredPrompts = prompts?.filter(prompt => {
    const matchesSearch = searchTerm === "" || 
      prompt.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prompt.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSector = selectedSector === "all" || prompt.industrySector === selectedSector;
    const matchesStyle = selectedStyle === "all" || prompt.visualStyle === selectedStyle;
    
    return matchesSearch && matchesSector && matchesStyle;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <Film className="h-8 w-8 text-indigo-600" />
              <h1 className="text-2xl font-bold text-slate-900">Prompts Vidéo Marketing</h1>
            </div>
          </Link>
          <nav className="flex items-center gap-4">
            <Link href="/gallery">
              <Button variant="ghost">Galerie</Button>
            </Link>
            <Link href="/documentation">
              <Button variant="ghost">Documentation</Button>
            </Link>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-4xl font-bold text-slate-900 mb-2">Explorer les Prompts</h2>
          <p className="text-lg text-slate-600">
            Parcourez notre collection de {prompts?.length || 50} prompts professionnels pour vidéos marketing
          </p>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filtres de Recherche</CardTitle>
            <CardDescription>Affinez votre recherche par mots-clés, secteur ou style</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Rechercher..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Sector Filter */}
              <Select value={selectedSector} onValueChange={setSelectedSector}>
                <SelectTrigger>
                  <SelectValue placeholder="Tous les secteurs" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les secteurs</SelectItem>
                  {stats?.sectors.map(sector => (
                    <SelectItem key={sector} value={sector}>{sector}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Style Filter */}
              <Select value={selectedStyle} onValueChange={setSelectedStyle}>
                <SelectTrigger>
                  <SelectValue placeholder="Tous les styles" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les styles</SelectItem>
                  {stats?.styles.map(style => (
                    <SelectItem key={style} value={style}>{style}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Results Count */}
            <div className="mt-4 text-sm text-slate-600">
              {filteredPrompts && (
                <p>
                  Affichage de <span className="font-semibold">{filteredPrompts.length}</span> prompt{filteredPrompts.length > 1 ? 's' : ''}
                  {(searchTerm || selectedSector !== "all" || selectedStyle !== "all") && 
                    ` sur ${prompts?.length || 0} au total`
                  }
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Prompts Grid */}
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-slate-600">Chargement des prompts...</p>
          </div>
        ) : filteredPrompts && filteredPrompts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPrompts.map(prompt => (
              <Card key={prompt.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-sm font-semibold text-indigo-600 bg-indigo-50 px-2 py-1 rounded">
                      Prompt #{prompt.promptNumber}
                    </span>
                    <span className="text-xs text-slate-500">
                      {prompt.durationSeconds}s
                    </span>
                  </div>
                  <CardTitle className="text-lg">{prompt.title}</CardTitle>
                  <CardDescription className="line-clamp-2">
                    {prompt.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="font-medium text-slate-700">Secteur:</span>
                      <span className="text-slate-600">{prompt.industrySector}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="font-medium text-slate-700">Style:</span>
                      <span className="text-slate-600">{prompt.visualStyle}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="font-medium text-slate-700">Scénario:</span>
                      <span className="text-slate-600">{prompt.scenarioType}</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Link href={`/prompt/${prompt.promptNumber}`} className="flex-1">
                      <Button className="w-full" variant="default">
                        Voir Détails
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(prompt.promptJson);
                        const downloadAnchorNode = document.createElement('a');
                        downloadAnchorNode.setAttribute("href", dataStr);
                        downloadAnchorNode.setAttribute("download", `prompt_${prompt.promptNumber}.json`);
                        document.body.appendChild(downloadAnchorNode);
                        downloadAnchorNode.click();
                        downloadAnchorNode.remove();
                      }}
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-12">
            <CardContent>
              <p className="text-slate-600 text-lg">Aucun prompt ne correspond à vos critères de recherche.</p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedSector("all");
                  setSelectedStyle("all");
                }}
              >
                Réinitialiser les filtres
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
