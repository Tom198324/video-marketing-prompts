import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Film, Code, BookOpen, Zap, Copy, Check } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { toast } from "sonner";

export default function Documentation() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    toast.success("Code copié dans le presse-papiers");
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const soraExample = `import OpenAI from 'openai';

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Charger votre prompt JSON
const promptData = {
  "shot": {
    "camera_system": "ARRI Alexa Mini LF",
    "primary_lens": "Zeiss Supreme Prime 50mm T1.5",
    // ... reste du prompt
  }
};

async function generateVideo() {
  const response = await client.videos.generate({
    model: "sora-2",
    prompt: JSON.stringify(promptData),
    size: "1920x1080",
    duration: 20
  });
  
  console.log("Vidéo générée:", response.url);
  return response;
}

generateVideo();`;

  const veoExample = `import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

// Charger votre prompt JSON
const promptData = {
  "shot": {
    "camera_system": "RED Komodo 6K",
    "primary_lens": "Cooke S7/i 50mm T2.0",
    // ... reste du prompt
  }
};

async function generateVideo() {
  const model = genAI.getGenerativeModel({ model: 'veo-3' });
  
  const result = await model.generateContent({
    prompt: JSON.stringify(promptData),
    videoConfig: {
      duration: 20,
      resolution: '1920x1080',
      fps: 24
    }
  });
  
  console.log("Vidéo générée:", result.response.videoUrl);
  return result;
}

generateVideo();`;

  const runwayExample = `import fetch from 'node-fetch';

const RUNWAY_API_KEY = process.env.RUNWAY_API_KEY;

// Charger votre prompt JSON
const promptData = {
  "shot": {
    "camera_system": "Sony Venice",
    "primary_lens": "Canon CN-E 50mm T1.3",
    // ... reste du prompt
  }
};

async function generateVideo() {
  const response = await fetch('https://api.runwayml.com/v1/gen3/generate', {
    method: 'POST',
    headers: {
      'Authorization': \`Bearer \${RUNWAY_API_KEY}\`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      prompt: JSON.stringify(promptData),
      duration: 20,
      resolution: '1920x1080'
    })
  });
  
  const data = await response.json();
  console.log("Vidéo générée:", data.videoUrl);
  return data;
}

generateVideo();`;

  const customizationExample = `// Exemple de personnalisation d'un prompt
const basePrompt = await fetch('/api/prompts/1').then(r => r.json());
const promptData = JSON.parse(basePrompt.promptJson);

// Personnaliser le sujet
promptData.subject.identity.age = "35 ans";
promptData.subject.identity.gender = "Femme";
promptData.subject.appearance.description = "Professionnelle confiante aux cheveux courts";

// Personnaliser la scène
promptData.scene.location = "Bureau moderne avec vue sur la ville";
promptData.scene.time_of_day = "Matin doré (8h-9h)";

// Personnaliser l'audio
promptData.audio.music = "Musique corporate inspirante et dynamique";

// Utiliser le prompt personnalisé
console.log(JSON.stringify(promptData, null, 2));`;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <Film className="h-8 w-8 text-indigo-600" />
              <h1 className="text-2xl font-bold text-slate-900">Prompts Vidéo Marketing</h1>
            </div>
          </Link>
          <nav className="flex items-center gap-4">
            <Link href="/prompts">
              <Button variant="ghost">Explorer</Button>
            </Link>
            <Link href="/gallery">
              <Button variant="ghost">Galerie</Button>
            </Link>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-4xl font-bold text-slate-900 mb-2">Documentation</h2>
          <p className="text-lg text-slate-600">
            Guides complets pour utiliser les prompts JSON avec Sora 2, Veo 3 et Runway Gen-3
          </p>
        </div>

        {/* Quick Start */}
        <Card className="mb-8 border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Zap className="h-8 w-8 text-indigo-600" />
              <div>
                <CardTitle className="text-2xl">Démarrage Rapide</CardTitle>
                <CardDescription className="text-base">Commencez à générer des vidéos en 3 étapes simples</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="flex items-center justify-center w-12 h-12 bg-indigo-600 text-white rounded-full font-bold text-xl mb-3">
                  1
                </div>
                <h3 className="font-semibold text-slate-900">Choisissez un Prompt</h3>
                <p className="text-sm text-slate-600">
                  Parcourez notre collection de 50 prompts et sélectionnez celui qui correspond à votre besoin marketing.
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-center w-12 h-12 bg-purple-600 text-white rounded-full font-bold text-xl mb-3">
                  2
                </div>
                <h3 className="font-semibold text-slate-900">Téléchargez le JSON</h3>
                <p className="text-sm text-slate-600">
                  Cliquez sur le bouton de téléchargement pour obtenir le fichier JSON complet du prompt sélectionné.
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-center w-12 h-12 bg-pink-600 text-white rounded-full font-bold text-xl mb-3">
                  3
                </div>
                <h3 className="font-semibold text-slate-900">Générez la Vidéo</h3>
                <p className="text-sm text-slate-600">
                  Utilisez le prompt avec votre plateforme préférée (Sora 2, Veo 3, Runway Gen-3) pour créer votre vidéo.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Documentation Tabs */}
        <Tabs defaultValue="structure" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="structure">Structure</TabsTrigger>
            <TabsTrigger value="sora">Sora 2</TabsTrigger>
            <TabsTrigger value="veo">Veo 3</TabsTrigger>
            <TabsTrigger value="runway">Runway</TabsTrigger>
            <TabsTrigger value="custom">Personnalisation</TabsTrigger>
            <TabsTrigger value="api">API LLM</TabsTrigger>
          </TabsList>

          {/* Structure Tab */}
          <TabsContent value="structure" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <BookOpen className="h-6 w-6 text-indigo-600" />
                  <CardTitle>Structure des Prompts JSON</CardTitle>
                </div>
                <CardDescription>
                  Chaque prompt contient 8 sections obligatoires pour une génération vidéo professionnelle
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border-l-4 border-indigo-600 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-2">1. Shot</h3>
                    <p className="text-sm text-slate-600">
                      Définit le système de caméra, l'objectif, la composition, le mouvement de caméra et les paramètres techniques de prise de vue.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-purple-600 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-2">2. Subject</h3>
                    <p className="text-sm text-slate-600">
                      Décrit l'identité du sujet (âge, genre), son apparence physique, sa garde-robe et son expression émotionnelle.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-pink-600 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-2">3. Action</h3>
                    <p className="text-sm text-slate-600">
                      Séquences d'actions avec timing précis, mouvements principaux et suivi de caméra pour chaque phase de la vidéo.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-blue-600 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-2">4. Scene</h3>
                    <p className="text-sm text-slate-600">
                      Lieu de tournage, moment de la journée, environnement, conditions météorologiques et ambiance générale.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-green-600 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-2">5. Cinematography</h3>
                    <p className="text-sm text-slate-600">
                      Éclairage (source, qualité, température, ratio key/fill), profondeur de champ et évolution lumineuse.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-yellow-600 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-2">6. Audio</h3>
                    <p className="text-sm text-slate-600">
                      Sons ambiants, effets foley, musique de fond et synchronisation audio-visuelle.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-red-600 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-2">7. Visual Rules</h3>
                    <p className="text-sm text-slate-600">
                      Règles de réalisme, continuité visuelle, cohérence temporelle et restrictions techniques.
                    </p>
                  </div>
                  
                  <div className="border-l-4 border-orange-600 pl-4">
                    <h3 className="font-semibold text-slate-900 mb-2">8. Technical Specifications</h3>
                    <p className="text-sm text-slate-600">
                      Résolution, espace colorimétrique, profondeur de bits, qualité de sortie et durée de la vidéo.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sora 2 Tab */}
          <TabsContent value="sora" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Code className="h-6 w-6 text-indigo-600" />
                    <div>
                      <CardTitle>Intégration avec OpenAI Sora 2</CardTitle>
                      <CardDescription>Exemple de code pour générer des vidéos avec l'API Sora 2</CardDescription>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(soraExample, 'sora')}
                  >
                    {copiedCode === 'sora' ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                    {copiedCode === 'sora' ? 'Copié' : 'Copier'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto text-sm">
                  <code>{soraExample}</code>
                </pre>
                
                <div className="mt-6 space-y-4">
                  <h3 className="font-semibold text-slate-900">Configuration Requise</h3>
                  <ul className="list-disc list-inside space-y-2 text-sm text-slate-600">
                    <li>Node.js 18+ ou Python 3.8+</li>
                    <li>Clé API OpenAI avec accès à Sora 2</li>
                    <li>Package <code className="bg-slate-100 px-2 py-1 rounded">openai</code> installé</li>
                  </ul>
                  
                  <h3 className="font-semibold text-slate-900 mt-4">Installation</h3>
                  <pre className="bg-slate-900 text-slate-100 p-3 rounded text-sm">
                    npm install openai
                  </pre>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Veo 3 Tab */}
          <TabsContent value="veo" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Code className="h-6 w-6 text-purple-600" />
                    <div>
                      <CardTitle>Intégration avec Google Veo 3</CardTitle>
                      <CardDescription>Exemple de code pour générer des vidéos avec l'API Veo 3</CardDescription>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(veoExample, 'veo')}
                  >
                    {copiedCode === 'veo' ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                    {copiedCode === 'veo' ? 'Copié' : 'Copier'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto text-sm">
                  <code>{veoExample}</code>
                </pre>
                
                <div className="mt-6 space-y-4">
                  <h3 className="font-semibold text-slate-900">Configuration Requise</h3>
                  <ul className="list-disc list-inside space-y-2 text-sm text-slate-600">
                    <li>Node.js 18+ ou Python 3.9+</li>
                    <li>Clé API Google Cloud avec accès à Veo 3</li>
                    <li>Package <code className="bg-slate-100 px-2 py-1 rounded">@google/generative-ai</code> installé</li>
                  </ul>
                  
                  <h3 className="font-semibold text-slate-900 mt-4">Installation</h3>
                  <pre className="bg-slate-900 text-slate-100 p-3 rounded text-sm">
                    npm install @google/generative-ai
                  </pre>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Runway Tab */}
          <TabsContent value="runway" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Code className="h-6 w-6 text-pink-600" />
                    <div>
                      <CardTitle>Intégration avec Runway Gen-3</CardTitle>
                      <CardDescription>Exemple de code pour générer des vidéos avec l'API Runway Gen-3</CardDescription>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(runwayExample, 'runway')}
                  >
                    {copiedCode === 'runway' ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                    {copiedCode === 'runway' ? 'Copié' : 'Copier'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto text-sm">
                  <code>{runwayExample}</code>
                </pre>
                
                <div className="mt-6 space-y-4">
                  <h3 className="font-semibold text-slate-900">Configuration Requise</h3>
                  <ul className="list-disc list-inside space-y-2 text-sm text-slate-600">
                    <li>Node.js 18+ ou Python 3.8+</li>
                    <li>Clé API Runway avec accès à Gen-3</li>
                    <li>Package <code className="bg-slate-100 px-2 py-1 rounded">node-fetch</code> ou <code className="bg-slate-100 px-2 py-1 rounded">axios</code></li>
                  </ul>
                  
                  <h3 className="font-semibold text-slate-900 mt-4">Installation</h3>
                  <pre className="bg-slate-900 text-slate-100 p-3 rounded text-sm">
                    npm install node-fetch
                  </pre>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Customization Tab */}
          <TabsContent value="custom" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Code className="h-6 w-6 text-blue-600" />
                    <div>
                      <CardTitle>Personnaliser les Prompts</CardTitle>
                      <CardDescription>Guide pour adapter les prompts à vos besoins spécifiques</CardDescription>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(customizationExample, 'custom')}
                  >
                    {copiedCode === 'custom' ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                    {copiedCode === 'custom' ? 'Copié' : 'Copier'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto text-sm mb-6">
                  <code>{customizationExample}</code>
                </pre>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-3">Éléments Personnalisables</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="border rounded-lg p-4">
                        <h4 className="font-medium text-slate-900 mb-2">Identité du Sujet</h4>
                        <ul className="text-sm text-slate-600 space-y-1">
                          <li>• Âge et genre</li>
                          <li>• Apparence physique</li>
                          <li>• Tenue vestimentaire</li>
                          <li>• Expression émotionnelle</li>
                        </ul>
                      </div>
                      
                      <div className="border rounded-lg p-4">
                        <h4 className="font-medium text-slate-900 mb-2">Environnement</h4>
                        <ul className="text-sm text-slate-600 space-y-1">
                          <li>• Lieu de tournage</li>
                          <li>• Moment de la journée</li>
                          <li>• Conditions météo</li>
                          <li>• Décor et accessoires</li>
                        </ul>
                      </div>
                      
                      <div className="border rounded-lg p-4">
                        <h4 className="font-medium text-slate-900 mb-2">Technique</h4>
                        <ul className="text-sm text-slate-600 space-y-1">
                          <li>• Caméra et objectif</li>
                          <li>• Mouvement de caméra</li>
                          <li>• Éclairage</li>
                          <li>• Composition</li>
                        </ul>
                      </div>
                      
                      <div className="border rounded-lg p-4">
                        <h4 className="font-medium text-slate-900 mb-2">Audio</h4>
                        <ul className="text-sm text-slate-600 space-y-1">
                          <li>• Ambiance sonore</li>
                          <li>• Effets foley</li>
                          <li>• Musique de fond</li>
                          <li>• Voix off (optionnel)</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-900 mb-2">💡 Conseil Pro</h4>
                    <p className="text-sm text-blue-800">
                      Conservez toujours la structure à 8 sections lors de la personnalisation. Modifiez uniquement les valeurs des propriétés, pas la structure JSON elle-même, pour garantir la compatibilité avec toutes les plateformes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* API LLM Tab */}
          <TabsContent value="api" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Code className="h-6 w-6 text-indigo-600" />
                  <CardTitle>API LLM Intégrée</CardTitle>
                </div>
                <CardDescription>
                  Utilisez l'intelligence artificielle pour générer automatiquement des variations de prompts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="prose prose-slate max-w-none">
                  <h3 className="text-xl font-semibold text-slate-900 mb-4">🎯 À quoi sert l'API LLM ?</h3>
                  <p className="text-slate-700 mb-4">
                    L'API LLM (Large Language Model) intégrée permet d'utiliser des <strong>modèles d'intelligence artificielle</strong> pour générer du contenu textuel intelligent. Dans ce projet, elle sert à :
                  </p>
                  <ul className="list-disc pl-6 space-y-2 text-slate-700 mb-6">
                    <li><strong>Générer des variations de prompts</strong> en modifiant intelligemment certains paramètres (personnage, lieu, style, etc.)</li>
                    <li><strong>Comprendre la structure JSON</strong> des prompts et produire des variations cohérentes</li>
                    <li><strong>Créer du contenu créatif</strong> tout en respectant les contraintes techniques (format JSON strict, sections obligatoires)</li>
                  </ul>

                  <h3 className="text-xl font-semibold text-slate-900 mb-4">⚙️ Comment fonctionne-t-elle ?</h3>
                  <p className="text-slate-700 mb-4">
                    L'API est accessible via la fonction <code className="bg-slate-100 px-2 py-1 rounded text-sm">invokeLLM()</code> située dans <code className="bg-slate-100 px-2 py-1 rounded text-sm">server/_core/llm.ts</code>.
                  </p>
                  
                  <div className="bg-slate-900 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 text-sm font-mono">TypeScript</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-slate-300 hover:text-white hover:bg-slate-800"
                        onClick={() => handleCopy(`import { invokeLLM } from "./server/_core/llm";

const response = await invokeLLM({
  messages: [
    { role: "system", content: "Tu es un assistant spécialisé..." },
    { role: "user", content: "Génère une variation de ce prompt..." }
  ],
  response_format: {
    type: "json_schema",
    json_schema: { /* Schéma JSON strict */ }
  }
});`, "llm-basic")}
                      >
                        {copiedCode === "llm-basic" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <pre className="text-sm text-slate-300 overflow-x-auto">
                      <code>{`import { invokeLLM } from "./server/_core/llm";

const response = await invokeLLM({
  messages: [
    { role: "system", content: "Tu es un assistant spécialisé..." },
    { role: "user", content: "Génère une variation de ce prompt..." }
  ],
  response_format: {
    type: "json_schema",
    json_schema: { /* Schéma JSON strict */ }
  }
});`}</code>
                    </pre>
                  </div>

                  <div className="bg-blue-50 border-l-4 border-blue-600 p-4 mb-6">
                    <h4 className="font-semibold text-blue-900 mb-2">Flux de fonctionnement</h4>
                    <ol className="list-decimal pl-6 space-y-2 text-blue-800">
                      <li><strong>Envoi de la requête</strong> : Vous envoyez des messages (instructions système + requête utilisateur)</li>
                      <li><strong>Traitement par l'IA</strong> : Le modèle LLM analyse le contexte et génère une réponse</li>
                      <li><strong>Validation du format</strong> : Si vous utilisez json_schema, l'IA garantit un JSON valide</li>
                      <li><strong>Retour de la réponse</strong> : Vous recevez le contenu généré dans response.choices[0].message.content</li>
                    </ol>
                  </div>

                  <h3 className="text-xl font-semibold text-slate-900 mb-4">🔌 Utilisation via une application tierce</h3>
                  <p className="text-slate-700 mb-4">
                    Vous pouvez intégrer l'API LLM dans vos applications externes de deux manières :
                  </p>

                  <h4 className="font-semibold text-slate-900 mb-3">1. Via des endpoints tRPC personnalisés (recommandé)</h4>
                  <p className="text-slate-700 mb-3">
                    Créez des endpoints tRPC qui exposent les fonctionnalités LLM :
                  </p>
                  
                  <div className="bg-slate-900 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 text-sm font-mono">TypeScript - server/routers.ts</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-slate-300 hover:text-white hover:bg-slate-800"
                        onClick={() => handleCopy(`myCustomGenerator: publicProcedure
  .input(z.object({ prompt: z.string() }))
  .mutation(async ({ input }) => {
    const response = await invokeLLM({
      messages: [
        { role: "user", content: input.prompt }
      ]
    });
    return { result: response.choices[0].message.content };
  })`, "llm-endpoint")}
                      >
                        {copiedCode === "llm-endpoint" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <pre className="text-sm text-slate-300 overflow-x-auto">
                      <code>{`myCustomGenerator: publicProcedure
  .input(z.object({ prompt: z.string() }))
  .mutation(async ({ input }) => {
    const response = await invokeLLM({
      messages: [
        { role: "user", content: input.prompt }
      ]
    });
    return { result: response.choices[0].message.content };
  })`}</code>
                    </pre>
                  </div>

                  <p className="text-slate-700 mb-3">
                    Ensuite, appelez cet endpoint depuis n'importe quelle application externe via HTTP :
                  </p>

                  <div className="bg-slate-900 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 text-sm font-mono">cURL</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-slate-300 hover:text-white hover:bg-slate-800"
                        onClick={() => handleCopy(`curl -X POST https://votre-site.manus.space/api/trpc/myCustomGenerator \\
  -H "Content-Type: application/json" \\
  -d '{"prompt": "Génère une description..."}'`, "llm-curl")}
                      >
                        {copiedCode === "llm-curl" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <pre className="text-sm text-slate-300 overflow-x-auto">
                      <code>{`curl -X POST https://votre-site.manus.space/api/trpc/myCustomGenerator \\
  -H "Content-Type: application/json" \\
  -d '{"prompt": "Génère une description..."}'`}</code>
                    </pre>
                  </div>

                  <h4 className="font-semibold text-slate-900 mb-3">2. Intégration Python</h4>
                  <p className="text-slate-700 mb-3">
                    Exemple d'intégration depuis une application Python :
                  </p>

                  <div className="bg-slate-900 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 text-sm font-mono">Python</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-slate-300 hover:text-white hover:bg-slate-800"
                        onClick={() => handleCopy(`import requests

response = requests.post(
    "https://votre-site.manus.space/api/trpc/generator.generateVariation",
    json={
        "promptId": 1,
        "variations": {"subject": True, "location": True},
        "count": 3
    }
)

variations = response.json()["result"]["data"]["variations"]
print(f"Généré {len(variations)} variations !")`, "llm-python")}
                      >
                        {copiedCode === "llm-python" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <pre className="text-sm text-slate-300 overflow-x-auto">
                      <code>{`import requests

response = requests.post(
    "https://votre-site.manus.space/api/trpc/generator.generateVariation",
    json={
        "promptId": 1,
        "variations": {"subject": True, "location": True},
        "count": 3
    }
)

variations = response.json()["result"]["data"]["variations"]
print(f"Généré {len(variations)} variations !")`}</code>
                    </pre>
                  </div>

                  <h4 className="font-semibold text-slate-900 mb-3">3. Intégration JavaScript/Node.js</h4>
                  <p className="text-slate-700 mb-3">
                    Exemple avec fetch (navigateur) ou axios (Node.js) :
                  </p>

                  <div className="bg-slate-900 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 text-sm font-mono">JavaScript</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-slate-300 hover:text-white hover:bg-slate-800"
                        onClick={() => handleCopy(`// Avec fetch (navigateur ou Node.js 18+)
fetch('https://votre-site.manus.space/api/trpc/generator.generateVariation', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    promptId: 1,
    variations: { subject: true, location: true },
    count: 3
  })
})
.then(res => res.json())
.then(data => {
  const variations = data.result.data.variations;
  console.log(\`Généré \${variations.length} variations !\`);
});

// Avec axios (Node.js)
const axios = require('axios');

const response = await axios.post(
  'https://votre-site.manus.space/api/trpc/generator.generateVariation',
  {
    promptId: 1,
    variations: { subject: true, location: true },
    count: 3
  }
);

const variations = response.data.result.data.variations;
console.log(\`Généré \${variations.length} variations !\`);`, "llm-javascript")}
                      >
                        {copiedCode === "llm-javascript" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <pre className="text-sm text-slate-300 overflow-x-auto">
                      <code>{`// Avec fetch (navigateur ou Node.js 18+)
fetch('https://votre-site.manus.space/api/trpc/generator.generateVariation', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    promptId: 1,
    variations: { subject: true, location: true },
    count: 3
  })
})
.then(res => res.json())
.then(data => {
  const variations = data.result.data.variations;
  console.log(\`Généré \${variations.length} variations !\`);
});

// Avec axios (Node.js)
const axios = require('axios');

const response = await axios.post(
  'https://votre-site.manus.space/api/trpc/generator.generateVariation',
  {
    promptId: 1,
    variations: { subject: true, location: true },
    count: 3
  }
);

const variations = response.data.result.data.variations;
console.log(\`Généré \${variations.length} variations !\`);`}</code>
                    </pre>
                  </div>

                  <h4 className="font-semibold text-slate-900 mb-3">4. Intégration Go</h4>
                  <p className="text-slate-700 mb-3">
                    Exemple avec le package net/http standard :
                  </p>

                  <div className="bg-slate-900 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 text-sm font-mono">Go</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-slate-300 hover:text-white hover:bg-slate-800"
                        onClick={() => handleCopy(`package main

import (
    "bytes"
    "encoding/json"
    "fmt"
    "io"
    "net/http"
)

type Request struct {
    PromptID   int                    \`json:"promptId"\`
    Variations map[string]bool        \`json:"variations"\`
    Count      int                    \`json:"count"\`
}

type Response struct {
    Result struct {
        Data struct {
            Variations []map[string]interface{} \`json:"variations"\`
        } \`json:"data"\`
    } \`json:"result"\`
}

func main() {
    reqData := Request{
        PromptID: 1,
        Variations: map[string]bool{
            "subject":  true,
            "location": true,
        },
        Count: 3,
    }

    jsonData, _ := json.Marshal(reqData)
    
    resp, err := http.Post(
        "https://votre-site.manus.space/api/trpc/generator.generateVariation",
        "application/json",
        bytes.NewBuffer(jsonData),
    )
    if err != nil {
        panic(err)
    }
    defer resp.Body.Close()

    body, _ := io.ReadAll(resp.Body)
    
    var result Response
    json.Unmarshal(body, &result)
    
    fmt.Printf("Généré %d variations !\\n", len(result.Result.Data.Variations))
}`, "llm-go")}
                      >
                        {copiedCode === "llm-go" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <pre className="text-sm text-slate-300 overflow-x-auto">
                      <code>{`package main

import (
    "bytes"
    "encoding/json"
    "fmt"
    "io"
    "net/http"
)

type Request struct {
    PromptID   int                    \`json:"promptId"\`
    Variations map[string]bool        \`json:"variations"\`
    Count      int                    \`json:"count"\`
}

type Response struct {
    Result struct {
        Data struct {
            Variations []map[string]interface{} \`json:"variations"\`
        } \`json:"data"\`
    } \`json:"result"\`
}

func main() {
    reqData := Request{
        PromptID: 1,
        Variations: map[string]bool{
            "subject":  true,
            "location": true,
        },
        Count: 3,
    }

    jsonData, _ := json.Marshal(reqData)
    
    resp, err := http.Post(
        "https://votre-site.manus.space/api/trpc/generator.generateVariation",
        "application/json",
        bytes.NewBuffer(jsonData),
    )
    if err != nil {
        panic(err)
    }
    defer resp.Body.Close()

    body, _ := io.ReadAll(resp.Body)
    
    var result Response
    json.Unmarshal(body, &result)
    
    fmt.Printf("Généré %d variations !\\n", len(result.Result.Data.Variations))
}`}</code>
                    </pre>
                  </div>

                  <h4 className="font-semibold text-slate-900 mb-3">5. Intégration PHP</h4>
                  <p className="text-slate-700 mb-3">
                    Exemple avec cURL :
                  </p>

                  <div className="bg-slate-900 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 text-sm font-mono">PHP</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-slate-300 hover:text-white hover:bg-slate-800"
                        onClick={() => handleCopy(`<?php

$url = 'https://votre-site.manus.space/api/trpc/generator.generateVariation';

$data = [
    'promptId' => 1,
    'variations' => [
        'subject' => true,
        'location' => true
    ],
    'count' => 3
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$variations = $result['result']['data']['variations'];

echo "Généré " . count($variations) . " variations !\\n";

?>`, "llm-php")}
                      >
                        {copiedCode === "llm-php" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <pre className="text-sm text-slate-300 overflow-x-auto">
                      <code>{`<?php

$url = 'https://votre-site.manus.space/api/trpc/generator.generateVariation';

$data = [
    'promptId' => 1,
    'variations' => [
        'subject' => true,
        'location' => true
    ],
    'count' => 3
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$variations = $result['result']['data']['variations'];

echo "Généré " . count($variations) . " variations !\\n";

?>`}</code>
                    </pre>
                  </div>

                  <h4 className="font-semibold text-slate-900 mb-3">6. Intégration Ruby</h4>
                  <p className="text-slate-700 mb-3">
                    Exemple avec Net::HTTP :
                  </p>

                  <div className="bg-slate-900 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 text-sm font-mono">Ruby</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 text-slate-300 hover:text-white hover:bg-slate-800"
                        onClick={() => handleCopy(`require 'net/http'
require 'json'
require 'uri'

uri = URI('https://votre-site.manus.space/api/trpc/generator.generateVariation')

data = {
  promptId: 1,
  variations: {
    subject: true,
    location: true
  },
  count: 3
}

http = Net::HTTP.new(uri.host, uri.port)
http.use_ssl = true

request = Net::HTTP::Post.new(uri.path, {'Content-Type' => 'application/json'})
request.body = data.to_json

response = http.request(request)
result = JSON.parse(response.body)

variations = result['result']['data']['variations']
puts "Généré #{variations.length} variations !"`, "llm-ruby")}
                      >
                        {copiedCode === "llm-ruby" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <pre className="text-sm text-slate-300 overflow-x-auto">
                      <code>{`require 'net/http'
require 'json'
require 'uri'

uri = URI('https://votre-site.manus.space/api/trpc/generator.generateVariation')

data = {
  promptId: 1,
  variations: {
    subject: true,
    location: true
  },
  count: 3
}

http = Net::HTTP.new(uri.host, uri.port)
http.use_ssl = true

request = Net::HTTP::Post.new(uri.path, {'Content-Type' => 'application/json'})
request.body = data.to_json

response = http.request(request)
result = JSON.parse(response.body)

variations = result['result']['data']['variations']
puts "Généré #{variations.length} variations !"`}</code>
                    </pre>
                  </div>

                  <h3 className="text-xl font-semibold text-slate-900 mb-4">🔒 Sécurité et bonnes pratiques</h3>
                  <div className="bg-red-50 border-l-4 border-red-600 p-4">
                    <ul className="list-disc pl-6 space-y-2 text-red-800">
                      <li><strong>Ne jamais exposer les clés API</strong> côté client (frontend)</li>
                      <li><strong>Toujours passer par le backend</strong> (tRPC) pour les appels LLM</li>
                      <li><strong>Limiter les requêtes</strong> si vous exposez publiquement (rate limiting)</li>
                      <li><strong>Valider les entrées</strong> pour éviter les injections de prompts malveillants</li>
                    </ul>
                  </div>

                  <div className="bg-green-50 border-l-4 border-green-600 p-4 mt-6">
                    <h4 className="font-semibold text-green-900 mb-2">💡 Cas d'usage pour applications tierces</h4>
                    <ul className="list-disc pl-6 space-y-2 text-green-800">
                      <li><strong>Intégration mobile</strong> : Créez une app iOS/Android qui appelle vos endpoints tRPC</li>
                      <li><strong>Automatisation</strong> : Scripts Python/Node.js qui génèrent des prompts en masse</li>
                      <li><strong>Webhooks</strong> : Déclenchez la génération depuis d'autres services (Zapier, Make, etc.)</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* FAQ Section */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Questions Fréquentes (FAQ)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Quelle plateforme choisir ?</h3>
              <p className="text-sm text-slate-600">
                <strong>Sora 2</strong> excelle pour le réalisme et les mouvements de caméra complexes. 
                <strong> Veo 3</strong> offre une excellente cohérence temporelle et des personnages détaillés. 
                <strong> Runway Gen-3</strong> est idéal pour l'itération rapide et les modifications créatives.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Puis-je modifier la durée des vidéos ?</h3>
              <p className="text-sm text-slate-600">
                Oui ! Tous nos prompts sont configurés pour 20 secondes, mais vous pouvez ajuster le paramètre <code className="bg-slate-100 px-2 py-1 rounded">duration</code> dans les spécifications techniques selon vos besoins.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Les prompts fonctionnent-ils en plusieurs langues ?</h3>
              <p className="text-sm text-slate-600">
                Les prompts sont en anglais pour une compatibilité maximale avec toutes les plateformes. Vous pouvez traduire les descriptions textuelles, mais conservez les termes techniques (noms de caméras, objectifs) en anglais.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Combien coûte la génération d'une vidéo ?</h3>
              <p className="text-sm text-slate-600">
                Les coûts varient selon la plateforme : Sora 2 (~$0.20-0.50/vidéo), Veo 3 (~$0.15-0.40/vidéo), Runway Gen-3 (~$0.10-0.30/vidéo). Consultez les tarifs actuels sur chaque plateforme.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Puis-je utiliser les vidéos à des fins commerciales ?</h3>
              <p className="text-sm text-slate-600">
                Oui, les prompts sont libres d'utilisation. Vérifiez cependant les conditions d'utilisation commerciale de la plateforme de génération que vous utilisez (Sora 2, Veo 3, ou Runway Gen-3).
              </p>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <Card className="mt-8 bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-0">
          <CardHeader className="text-center space-y-4 py-8">
            <CardTitle className="text-3xl">Prêt à Créer ?</CardTitle>
            <CardDescription className="text-white/90 text-lg">
              Explorez notre collection de 50 prompts et commencez à générer des vidéos professionnelles
            </CardDescription>
            <div className="pt-4">
              <Link href="/prompts">
                <Button size="lg" variant="secondary">
                  Explorer les Prompts
                </Button>
              </Link>
            </div>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
}
