import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Film, Play, ExternalLink } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

// Vidéos exemples de démonstration
// Note: Ces URLs sont des placeholders. En production, remplacez par vos vraies vidéos générées
const exampleVideos = [
  {
    id: 1,
    promptNumber: 1,
    title: "Lancement Smartphone Premium",
    description: "Homme 28 ans présentant un nouveau smartphone dans un environnement tech moderne",
    sector: "Consumer Electronics",
    style: "Hyperréaliste Cinématique",
    platform: "Sora 2",
    thumbnailUrl: "https://images.unsplash.com/photo-1556656793-08538906a9f8?w=800&h=450&fit=crop",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Placeholder
    duration: "20s",
  },
  {
    id: 2,
    promptNumber: 2,
    title: "Sérum Anti-Âge Luxe",
    description: "Femme 42 ans appliquant un sérum de luxe dans une salle de bain élégante",
    sector: "Health & Beauty",
    style: "Elegant Luxe",
    platform: "Veo 3",
    thumbnailUrl: "https://images.unsplash.com/photo-1596755389378-c31d21fd1273?w=800&h=450&fit=crop",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Placeholder
    duration: "20s",
  },
  {
    id: 3,
    promptNumber: 15,
    title: "Clinique Dentaire Moderne",
    description: "Dentiste professionnelle dans une clinique high-tech avec équipement de pointe",
    sector: "Healthcare Services",
    style: "Hyperréaliste Cinématique",
    platform: "Runway Gen-3",
    thumbnailUrl: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800&h=450&fit=crop",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Placeholder
    duration: "20s",
  },
  {
    id: 4,
    promptNumber: 8,
    title: "Restaurant Gastronomique",
    description: "Chef présentant un plat signature dans une cuisine professionnelle",
    sector: "Food & Beverage",
    style: "Hyperréaliste Cinématique",
    platform: "Sora 2",
    thumbnailUrl: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&h=450&fit=crop",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Placeholder
    duration: "20s",
  },
  {
    id: 5,
    promptNumber: 22,
    title: "Studio Fitness Premium",
    description: "Coach fitness dans un studio moderne avec équipement haut de gamme",
    sector: "Fitness & Wellness",
    style: "Lifestyle Aspirationnel",
    platform: "Veo 3",
    thumbnailUrl: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&h=450&fit=crop",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Placeholder
    duration: "20s",
  },
  {
    id: 6,
    promptNumber: 35,
    title: "Boutique Mode Luxe",
    description: "Styliste présentant une collection dans une boutique design",
    sector: "Fashion & Apparel",
    style: "Elegant Luxe",
    platform: "Runway Gen-3",
    thumbnailUrl: "https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=800&h=450&fit=crop",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Placeholder
    duration: "20s",
  },
];

export default function Gallery() {
  const [selectedSector, setSelectedSector] = useState<string>("all");
  const [selectedPlatform, setSelectedPlatform] = useState<string>("all");

  const sectors = Array.from(new Set(exampleVideos.map(v => v.sector)));
  const platforms = Array.from(new Set(exampleVideos.map(v => v.platform)));

  const filteredVideos = exampleVideos.filter(video => {
    const matchesSector = selectedSector === "all" || video.sector === selectedSector;
    const matchesPlatform = selectedPlatform === "all" || video.platform === selectedPlatform;
    return matchesSector && matchesPlatform;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <Film className="h-8 w-8 text-indigo-600" />
              <h1 className="text-2xl font-bold text-slate-900">Prompts Vidéo Marketing</h1>
            </div>
          </Link>
          <nav className="flex items-center gap-4">
            <Link href="/prompts">
              <Button variant="ghost">Explorer</Button>
            </Link>
            <Link href="/documentation">
              <Button variant="ghost">Documentation</Button>
            </Link>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-4xl font-bold text-slate-900 mb-2">Galerie Vidéos</h2>
          <p className="text-lg text-slate-600">
            Découvrez des exemples de vidéos générées avec nos prompts professionnels
          </p>
        </div>

        {/* Info Banner */}
        <Card className="mb-8 border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <Play className="h-6 w-6 text-indigo-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">Vidéos de Démonstration</h3>
                <p className="text-sm text-slate-600">
                  Ces vidéos ont été générées en utilisant nos prompts JSON avec différentes plateformes (Sora 2, Veo 3, Runway Gen-3). 
                  Chaque vidéo démontre la qualité et le réalisme que vous pouvez obtenir en utilisant nos prompts professionnels.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filtres</CardTitle>
            <CardDescription>Affinez votre recherche par secteur ou plateforme</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select value={selectedSector} onValueChange={setSelectedSector}>
                <SelectTrigger>
                  <SelectValue placeholder="Tous les secteurs" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les secteurs</SelectItem>
                  {sectors.map(sector => (
                    <SelectItem key={sector} value={sector}>{sector}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                <SelectTrigger>
                  <SelectValue placeholder="Toutes les plateformes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Toutes les plateformes</SelectItem>
                  {platforms.map(platform => (
                    <SelectItem key={platform} value={platform}>{platform}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="mt-4 text-sm text-slate-600">
              Affichage de <span className="font-semibold">{filteredVideos.length}</span> vidéo{filteredVideos.length > 1 ? 's' : ''}
            </div>
          </CardContent>
        </Card>

        {/* Videos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map(video => (
            <Card key={video.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative aspect-video bg-slate-200">
                <img 
                  src={video.thumbnailUrl} 
                  alt={video.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                  <a 
                    href={video.videoUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-white rounded-full p-4 hover:scale-110 transition-transform"
                  >
                    <Play className="h-8 w-8 text-indigo-600" />
                  </a>
                </div>
              </div>
              
              <CardHeader>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <Badge variant="secondary" className="text-xs">
                    Prompt #{video.promptNumber}
                  </Badge>
                  <Badge className="text-xs bg-indigo-600">
                    {video.platform}
                  </Badge>
                </div>
                <CardTitle className="text-lg">{video.title}</CardTitle>
                <CardDescription className="line-clamp-2">
                  {video.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Secteur:</span>
                    <span className="font-medium text-slate-900">{video.sector}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Style:</span>
                    <span className="font-medium text-slate-900">{video.style}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Durée:</span>
                    <span className="font-medium text-slate-900">{video.duration}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Link href={`/prompt/${video.promptNumber}`} className="flex-1">
                    <Button variant="default" className="w-full" size="sm">
                      Voir le Prompt
                    </Button>
                  </Link>
                  <a 
                    href={video.videoUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <Button variant="outline" size="sm">
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredVideos.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <p className="text-slate-600 text-lg mb-4">Aucune vidéo ne correspond à vos critères de recherche.</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedSector("all");
                  setSelectedPlatform("all");
                }}
              >
                Réinitialiser les filtres
              </Button>
            </CardContent>
          </Card>
        )}

        {/* CTA Section */}
        <Card className="mt-12 bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-0">
          <CardHeader className="text-center space-y-4 py-8">
            <CardTitle className="text-3xl">Créez Vos Propres Vidéos</CardTitle>
            <CardDescription className="text-white/90 text-lg">
              Utilisez nos prompts professionnels pour générer des vidéos marketing de qualité similaire
            </CardDescription>
            <div className="flex gap-4 justify-center pt-4">
              <Link href="/prompts">
                <Button size="lg" variant="secondary">
                  Explorer les Prompts
                </Button>
              </Link>
              <Link href="/documentation">
                <Button size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white/10">
                  Voir la Documentation
                </Button>
              </Link>
            </div>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
}
