import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { ArrowRight, Database, Download, Film, Lock, Search, Sparkles } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { isAuthenticated, loading } = useAuth();
  const { data: stats } = trpc.prompts.getStats.useQuery();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Film className="h-8 w-8 text-indigo-600" />
            <h1 className="text-2xl font-bold text-slate-900">Prompts Vidéo Marketing</h1>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/prompts">
              <Button variant="ghost">Explorer</Button>
            </Link>
            <Link href="/gallery">
              <Button variant="ghost">Galerie</Button>
            </Link>
            <Link href="/generator">
              <Button variant="ghost">Générateur</Button>
            </Link>
            <Link href="/documentation">
              <Button variant="ghost">Documentation</Button>
            </Link>
            {!loading && (
              isAuthenticated ? (
            <Link href="/prompts">
              <Button>Mes Prompts</Button>
            </Link>
              ) : (
                <a href={getLoginUrl()}>
                  <Button>
                    <Lock className="h-4 w-4 mr-2" />
                    Connexion
                  </Button>
                </a>
              )
            )}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium mb-4">
            <Sparkles className="h-4 w-4" />
            Collection Professionnelle de 50 Prompts JSON
          </div>
          
          <h2 className="text-5xl md:text-6xl font-bold text-slate-900 leading-tight">
            Créez des Vidéos Marketing
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600"> Hyperréalistes</span>
          </h2>
          
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Une collection complète de 50 prompts JSON professionnels pour générer des vidéos marketing de 20 secondes avec Sora 2, Veo 3 et Runway Gen-3.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Link href="/prompts">
              <Button size="lg" className="text-lg">
                Explorer les Prompts
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/documentation">
              <Button size="lg" variant="outline" className="text-lg">
                Documentation
              </Button>
            </Link>
            <a href="/prompts_enriched_v4.zip" download>
              <Button size="lg" variant="outline" className="text-lg border-green-600 text-green-600 hover:bg-green-50">
                <Download className="mr-2 h-5 w-5" />
                Télécharger ZIP v4.0 (212 KB)
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      {stats && (
        <section className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-4xl font-bold text-indigo-600">{stats.total}</CardTitle>
                <CardDescription>Prompts Disponibles</CardDescription>
              </CardHeader>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-4xl font-bold text-purple-600">{stats.sectors.length}</CardTitle>
                <CardDescription>Secteurs Couverts</CardDescription>
              </CardHeader>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-4xl font-bold text-pink-600">{stats.styles.length}</CardTitle>
                <CardDescription>Styles Visuels</CardDescription>
              </CardHeader>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-4xl font-bold text-blue-600">20s</CardTitle>
                <CardDescription>Durée Standard</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </section>
      )}

      {/* Examples Section */}
      <section className="container mx-auto px-4 py-20 bg-white/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-slate-900 mb-4">
              Exemples de Prompts
            </h3>
            <p className="text-lg text-slate-600">
              Découvrez la qualité professionnelle de nos prompts JSON
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Exemple 1 - Tech */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-medium">
                    Consumer Electronics
                  </span>
                  <span className="text-sm text-slate-500">20s</span>
                </div>
                <CardTitle className="text-lg">Lancement Smartphone Premium</CardTitle>
                <CardDescription>
                  Style: Hyperréaliste Cinématographique
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm text-slate-600">
                  <div>
                    <span className="font-semibold text-slate-900">Shot:</span> Plan rapproché du smartphone tournant lentement
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900">Caméra:</span> ARRI Alexa Mini LF + Zeiss Supreme Prime 50mm
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900">Résolution:</span> 4K (3840x2160) à 24fps
                  </div>
                </div>
                <Link href="/prompts/1">
                  <Button variant="outline" className="w-full mt-4">
                    Voir le prompt complet
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Exemple 2 - Beauty */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                    Health & Beauty
                  </span>
                  <span className="text-sm text-slate-500">20s</span>
                </div>
                <CardTitle className="text-lg">Sérum Anti-Âge Luxe</CardTitle>
                <CardDescription>
                  Style: Elegant Luxe
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm text-slate-600">
                  <div>
                    <span className="font-semibold text-slate-900">Shot:</span> Gros plan sur l'application du sérum
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900">Caméra:</span> RED Komodo 6K + Cooke S7/i 75mm
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900">Résolution:</span> 6K (6144x3240) à 24fps
                  </div>
                </div>
                <Link href="/prompts/2">
                  <Button variant="outline" className="w-full mt-4">
                    Voir le prompt complet
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Exemple 3 - Food */}
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-3 py-1 bg-pink-100 text-pink-700 rounded-full text-xs font-medium">
                    Food & Beverage
                  </span>
                  <span className="text-sm text-slate-500">20s</span>
                </div>
                <CardTitle className="text-lg">Café Artisanal Premium</CardTitle>
                <CardDescription>
                  Style: Lifestyle Aspirationnel
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm text-slate-600">
                  <div>
                    <span className="font-semibold text-slate-900">Shot:</span> Préparation du café par barista expert
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900">Caméra:</span> Sony Venice + Canon CN-E 85mm
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900">Résolution:</span> 6K (6048x4032) à 24fps
                  </div>
                </div>
                <Link href="/prompts/7">
                  <Button variant="outline" className="w-full mt-4">
                    Voir le prompt complet
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8">
            <Link href="/prompts">
              <Button size="lg" variant="outline">
                Voir tous les prompts
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <h3 className="text-3xl font-bold text-center text-slate-900 mb-12">
          Fonctionnalités Clés
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card>
            <CardHeader>
              <Database className="h-12 w-12 text-indigo-600 mb-4" />
              <CardTitle>Structure Professionnelle</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600">
                Chaque prompt contient 8 sections obligatoires : shot, subject, action, scene, cinematography, audio, visual_rules, et technical_specifications.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Search className="h-12 w-12 text-purple-600 mb-4" />
              <CardTitle>Recherche Avancée</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600">
                Filtrez par secteur d'industrie, style visuel, type de scénario, ou recherchez par mots-clés pour trouver le prompt parfait.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Download className="h-12 w-12 text-pink-600 mb-4" />
              <CardTitle>Export Flexible</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600">
                Téléchargez les prompts individuellement en JSON, ou exportez des collections complètes en ZIP pour votre workflow.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card className="max-w-4xl mx-auto bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-0">
          <CardHeader className="text-center space-y-4 py-12">
            <CardTitle className="text-4xl font-bold">
              Prêt à Créer des Vidéos Exceptionnelles ?
            </CardTitle>
            <CardDescription className="text-white/90 text-lg">
              Accédez à la collection complète de prompts professionnels et commencez à générer des vidéos marketing hyperréalistes dès aujourd'hui.
            </CardDescription>
            <div className="pt-4">
              <Link href="/prompts">
                <Button size="lg" variant="secondary" className="text-lg">
                  Commencer Maintenant
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </CardHeader>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t bg-white/80 backdrop-blur-sm mt-20">
        <div className="container mx-auto px-4 py-8 text-center text-slate-600">
          <p>© 2025 Prompts Vidéo Marketing - Collection Professionnelle</p>
          <p className="text-sm mt-2">50 prompts JSON pour Sora 2, Veo 3, et Runway Gen-3</p>
        </div>
      </footer>
    </div>
  );
}
