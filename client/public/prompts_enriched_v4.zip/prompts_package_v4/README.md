# Collection Professionnelle de 50 Prompts Vidéo Marketing

## 📋 Vue d'ensemble du projet

Cette collection représente un ensemble de **50 modèles de prompts JSON professionnels** conçus pour la génération de vidéos marketing hyperréalistes de 20 secondes minimum. Chaque prompt a été élaboré selon les directives officielles d'**OpenAI Sora 2** et de **Google Veo 3**, deux des plateformes les plus avancées en matière de génération vidéo par intelligence artificielle.

Le projet couvre **28 secteurs d'activité différents**, allant de la technologie à la beauté, en passant par l'alimentation, l'immobilier, la finance, et bien d'autres. Chaque prompt est structuré de manière rigoureuse pour garantir la cohérence cinématographique, le réalisme visuel, et la qualité professionnelle attendue dans les campagnes marketing modernes.

## 🎯 Objectifs du projet

L'objectif principal de cette collection est de fournir aux créateurs de contenu, aux agences marketing, et aux professionnels de la communication des **modèles prêts à l'emploi** qui peuvent être utilisés directement ou personnalisés selon les besoins spécifiques de chaque campagne. Ces prompts permettent de générer des vidéos marketing de haute qualité en quelques minutes, réduisant considérablement les coûts de production tout en maintenant des standards professionnels élevés.

## 📊 Statistiques de la collection

- **Nombre total de prompts** : 50
- **Secteurs couverts** : 28 industries différentes
- **Durée minimale des vidéos** : 20 secondes
- **Styles cinématographiques** : 15+ styles distincts (Cinematic, Documentary, Commercial, etc.)
- **Équipements référencés** : Caméras professionnelles (ARRI Alexa Mini LF, RED Komodo 6K) et objectifs haut de gamme (Zeiss Supreme Prime, Cooke S4/S7)
- **Résolutions supportées** : 4K, 6K, et 8K
- **Fréquences d'images** : 24fps, 30fps, 60fps, 120fps selon les besoins

## 🗂️ Structure des fichiers

Cette archive contient trois types de fichiers organisés de manière claire et accessible :

### 1. Dossier `prompts/` - Fichiers JSON individuels

Le dossier `prompts/` contient **50 fichiers JSON individuels**, chacun représentant un prompt complet pour la génération d'une vidéo marketing. Les fichiers sont nommés de manière séquentielle :

```
prompts/
├── prompt_01.json
├── prompt_02.json
├── prompt_03.json
├── ...
└── prompt_50.json
```

Chaque fichier JSON contient **8 sections obligatoires** qui définissent tous les aspects de la vidéo à générer :

1. **shot** : Type de plan, angle de caméra, cadrage
2. **subject** : Description détaillée du personnage principal
3. **action** : Séquences d'actions avec timing précis
4. **scene** : Lieu, éclairage, atmosphère
5. **cinematography** : Équipement (caméra, objectif, mouvements)
6. **audio** : Ambiance sonore et recommandations audio
7. **visual_rules** : Règles de réalisme et de continuité cinématographique
8. **technical_specifications** : Résolution, FPS, durée, format

### 2. Fichier `index.csv` - Index détaillé

Le fichier `index.csv` fournit une **vue d'ensemble rapide** de tous les prompts avec 9 colonnes :

| Colonne | Description |
|---------|-------------|
| **Numéro** | Identifiant du prompt (prompt_01, prompt_02, etc.) |
| **Shot** | Type de plan, angle, cadrage |
| **Subject** | Âge, genre, ethnicité du personnage |
| **Action** | Nombre de séquences et durée totale |
| **Scene** | Lieu et type d'éclairage |
| **Cinematography** | Caméra et objectif utilisés |
| **Audio** | Description de l'ambiance sonore |
| **Visual_Rules** | Aperçu des règles de réalisme et continuité |
| **Technical_Specifications** | Résolution et fréquence d'images |
| **JSON_Complet** | Prompt JSON complet en une seule cellule |

Ce fichier CSV peut être ouvert avec Excel, Google Sheets, ou tout autre logiciel de tableur pour une consultation rapide et des opérations de tri ou de filtrage.

### 3. Fichier `README.md` - Documentation complète

Le présent fichier README fournit toutes les informations nécessaires pour comprendre, utiliser, et personnaliser les prompts de cette collection.

## 🎬 Structure détaillée d'un prompt

Chaque prompt JSON suit une structure normalisée et complète. Voici un exemple de la structure type :

```json
{
  "shot": {
    "type": "Medium Shot",
    "angle": "Eye Level",
    "framing": "Rule of Thirds",
    "movement": "Slow Push In"
  },
  "subject": {
    "age": 32,
    "gender": "Female",
    "ethnicity": "Asian",
    "physical": "Athletic build, confident posture",
    "facial_features": "Focused expression, natural smile",
    "clothing": "Professional business attire",
    "emotional_state": "Confident and approachable"
  },
  "action": {
    "sequences": [
      {
        "timing": "0-8s",
        "primary_motion": "Walking through modern office",
        "camera_follows": "Smooth tracking shot"
      },
      {
        "timing": "8-15s",
        "primary_motion": "Interacting with digital interface",
        "camera_follows": "Static medium shot"
      },
      {
        "timing": "15-20s",
        "primary_motion": "Presenting to team",
        "camera_follows": "Slow zoom in"
      }
    ],
    "duration": "20 seconds"
  },
  "scene": {
    "location": "Modern corporate office",
    "time_of_day": "Morning",
    "weather": "Indoor controlled environment",
    "lighting": {
      "type": "Natural + Studio",
      "quality": "Soft diffused light",
      "direction": "Window light from left"
    },
    "atmosphere": "Professional, innovative, dynamic"
  },
  "cinematography": {
    "camera": "ARRI Alexa Mini LF",
    "lens": "Zeiss Supreme Prime 50mm T1.5",
    "aperture": "T2.8",
    "iso": "800",
    "shutter_speed": "1/50",
    "white_balance": "5600K",
    "color_profile": "Log C",
    "stabilization": "Gimbal + Optical IS"
  },
  "audio": {
    "ambient_sound": "Subtle office ambiance, keyboard typing, soft conversations",
    "music_style": "Corporate uplifting background music",
    "voice_over": "Optional professional narration"
  },
  "visual_rules": {
    "realism": "Textures réalistes avec détails fins (pores de peau, fibres textiles). Éclairage naturel avec ombres douces et reflets authentiques. Physique crédible des mouvements et interactions. Proportions anatomiques correctes et expressions faciales naturelles.",
    "continuity": "Cohérence de l'éclairage tout au long de la séquence. Transitions fluides entre les plans avec raccords de mouvement. Maintien des éléments de décor et accessoires. Direction du regard et axes de caméra respectés."
  },
  "technical_specifications": {
    "resolution": "4K (3840x2160)",
    "fps": "24",
    "aspect_ratio": "16:9",
    "color_space": "Rec. 2020",
    "bit_depth": "10-bit",
    "codec": "ProRes 422 HQ",
    "duration_seconds": 20
  }
}
```

## 🚀 Utilisation des prompts

### Avec OpenAI Sora 2

OpenAI Sora 2 accepte les prompts JSON structurés pour générer des vidéos de haute qualité. Voici comment utiliser un prompt de cette collection :

```python
import openai

# Charger un prompt depuis un fichier JSON
with open('prompts/prompt_01.json', 'r', encoding='utf-8') as f:
    prompt = json.load(f)

# Générer la vidéo avec Sora 2
response = openai.Video.create(
    model="sora-2",
    prompt=json.dumps(prompt),
    duration=20,
    resolution="4K"
)

# Télécharger la vidéo générée
video_url = response['data']['url']
```

### Avec Google Veo 3

Google Veo 3 utilise une approche similaire pour la génération vidéo :

```python
from google.cloud import video_generation

# Charger un prompt depuis un fichier JSON
with open('prompts/prompt_01.json', 'r', encoding='utf-8') as f:
    prompt = json.load(f)

# Initialiser le client Veo 3
client = video_generation.VideoGenerationClient()

# Générer la vidéo
request = video_generation.GenerateVideoRequest(
    prompt=json.dumps(prompt),
    duration_seconds=20,
    resolution="4K",
    fps=24
)

response = client.generate_video(request)
video_url = response.video_url
```

### Avec Runway Gen-3

Runway Gen-3 accepte également les prompts JSON structurés :

```python
import requests

# Charger un prompt depuis un fichier JSON
with open('prompts/prompt_01.json', 'r', encoding='utf-8') as f:
    prompt = json.load(f)

# API Runway Gen-3
url = "https://api.runwayml.com/v1/generate"
headers = {
    "Authorization": "Bearer YOUR_API_KEY",
    "Content-Type": "application/json"
}

payload = {
    "model": "gen-3",
    "prompt": prompt,
    "duration": 20,
    "resolution": "4K"
}

response = requests.post(url, json=payload, headers=headers)
video_url = response.json()['video_url']
```

## 🎨 Personnalisation des prompts

Les prompts de cette collection sont conçus pour être facilement personnalisables. Voici quelques exemples de modifications courantes :

### Modifier le personnage principal

Pour adapter le personnage à votre cible marketing :

```json
"subject": {
  "age": 28,
  "gender": "Male",
  "ethnicity": "Hispanic",
  "physical": "Casual athletic wear",
  "facial_features": "Friendly smile, approachable",
  "clothing": "Branded sportswear",
  "emotional_state": "Energetic and motivated"
}
```

### Ajuster la durée de la vidéo

Pour créer une vidéo plus longue ou plus courte :

```json
"action": {
  "sequences": [
    {
      "timing": "0-10s",
      "primary_motion": "Action principale",
      "camera_follows": "Mouvement de caméra"
    },
    {
      "timing": "10-20s",
      "primary_motion": "Action secondaire",
      "camera_follows": "Mouvement de caméra"
    },
    {
      "timing": "20-30s",
      "primary_motion": "Action finale",
      "camera_follows": "Mouvement de caméra"
    }
  ],
  "duration": "30 seconds"
},
"technical_specifications": {
  "duration_seconds": 30
}
```

### Changer le style cinématographique

Pour adapter l'ambiance visuelle :

```json
"shot": {
  "type": "Wide Shot",
  "angle": "Low Angle",
  "framing": "Centered",
  "movement": "Drone Flyover"
},
"cinematography": {
  "camera": "RED Komodo 6K",
  "lens": "Cooke S7/i 25mm T2.0",
  "aperture": "T2.0",
  "color_profile": "REDWideGamutRGB"
}
```

## 📚 Secteurs couverts

Cette collection couvre 28 secteurs d'activité différents, permettant une utilisation dans pratiquement tous les domaines du marketing :

1. **Technologie** : Startups, SaaS, IA, robotique
2. **Beauté & Cosmétiques** : Soins de la peau, maquillage, parfums
3. **Alimentation & Boissons** : Restaurants, produits alimentaires, boissons
4. **Mode & Luxe** : Vêtements, accessoires, joaillerie
5. **Immobilier** : Résidentiel, commercial, promotion immobilière
6. **Finance & Assurance** : Banques, investissements, assurances
7. **Santé & Bien-être** : Fitness, nutrition, médecine
8. **Automobile** : Véhicules, accessoires, services
9. **Voyage & Tourisme** : Destinations, hôtels, expériences
10. **Éducation** : Formations, cours en ligne, universités
11. **Sport & Loisirs** : Équipements, événements, clubs
12. **Électronique** : Smartphones, ordinateurs, gadgets
13. **Énergie & Environnement** : Énergies renouvelables, écologie
14. **Construction & Architecture** : Bâtiments, design, matériaux
15. **Médias & Divertissement** : Films, séries, jeux vidéo
16. **Retail & E-commerce** : Boutiques, marketplaces, services
17. **Services Professionnels** : Consulting, juridique, comptabilité
18. **Industrie & Manufacturing** : Production, logistique, supply chain
19. **Télécommunications** : Opérateurs, services internet
20. **Agriculture & Agroalimentaire** : Fermes, produits bio
21. **Pharmaceutique** : Médicaments, recherche, biotechnologie
22. **Art & Culture** : Galeries, musées, événements culturels
23. **ONG & Associations** : Causes sociales, humanitaire
24. **Événementiel** : Mariages, conférences, festivals
25. **Petcare** : Animaux de compagnie, vétérinaire
26. **Gaming** : Jeux vidéo, esports, streaming
27. **Blockchain & Crypto** : NFTs, DeFi, Web3
28. **Mobilité** : Vélos, trottinettes, transports urbains

## 🔧 Outils et équipements référencés

Les prompts de cette collection font référence à des équipements professionnels utilisés dans l'industrie cinématographique :

### Caméras

- **ARRI Alexa Mini LF** : Caméra cinéma full-frame de référence
- **RED Komodo 6K** : Caméra compacte haute résolution
- **Sony FX9** : Caméra professionnelle polyvalente
- **Canon C300 Mark III** : Caméra cinéma Canon
- **Blackmagic URSA Mini Pro 12K** : Caméra ultra haute résolution

### Objectifs

- **Zeiss Supreme Prime** : Objectifs cinéma haut de gamme
- **Cooke S4/S7** : Objectifs cinéma légendaires
- **Canon CN-E** : Objectifs cinéma Canon
- **Sigma Cine** : Objectifs cinéma abordables
- **Leica Summilux-C** : Objectifs cinéma premium

## 📖 Bonnes pratiques

Pour obtenir les meilleurs résultats avec ces prompts :

1. **Respectez la structure JSON** : Ne supprimez pas de sections obligatoires
2. **Adaptez le timing** : Ajustez les séquences selon vos besoins
3. **Testez plusieurs variations** : Générez plusieurs versions avec de légères modifications
4. **Vérifiez la cohérence** : Assurez-vous que toutes les sections sont cohérentes entre elles
5. **Optimisez pour votre plateforme** : Adaptez les spécifications techniques selon la plateforme cible

## 🆘 Support et ressources

Pour toute question ou assistance concernant l'utilisation de ces prompts :

- **Documentation OpenAI Sora 2** : https://openai.com/sora
- **Documentation Google Veo 3** : https://cloud.google.com/video-generation
- **Documentation Runway Gen-3** : https://runwayml.com/gen-3

## 📄 Licence et utilisation

Cette collection de prompts est fournie à des fins professionnelles. Les prompts peuvent être utilisés, modifiés, et adaptés librement pour vos projets marketing. Aucune attribution n'est requise, mais elle est toujours appréciée.

## 🎉 Conclusion

Cette collection représente des centaines d'heures de travail de recherche, de structuration, et d'optimisation pour vous fournir des prompts de la plus haute qualité. Nous espérons qu'elle vous permettra de créer des vidéos marketing exceptionnelles et de faire passer vos campagnes au niveau supérieur.

**Bonne création !** 🚀
