# Collection de 50 Prompts Vidéo Marketing Professionnels (Version Enrichie)

## 📦 Contenu du Package

Ce package contient une collection complète de 50 prompts JSON professionnels pour générer des vidéos marketing hyperréalistes de 20 secondes avec Sora 2, Veo 3 et Runway Gen-3.

### Fichiers Inclus

- **50_prompts_video_marketing_enrichis.json** - Collection complète des 50 prompts au format JSON
- **index.csv** - Index tabulaire pour navigation rapide
- **README.md** - Ce fichier de documentation

## ✨ Nouveautés Version Enrichie

Cette version inclut des **sections Réalisme et Continuité complétées** pour chaque prompt :

### Réalisme
- Textures et matériaux détaillés
- Comportement physique réaliste
- Éclairage et ombres cohérents
- Détails environnementaux précis

### Continuité
- Cohérence temporelle entre les séquences
- Transitions fluides des mouvements
- Maintien de l'éclairage et de l'ambiance
- Respect de la logique narrative

## 🎯 Structure JSON (8 Sections Obligatoires)

Chaque prompt contient les sections suivantes :

1. **shot** - Configuration caméra et composition
2. **subject** - Description détaillée du sujet
3. **action** - Séquences d'actions avec timing
4. **scene** - Environnement et contexte
5. **cinematography** - Éclairage et color grading
6. **audio** - Ambiance sonore et musique
7. **visual_rules** - Réalisme et continuité (✨ ENRICHI)
8. **technical_specifications** - Spécifications techniques

## 📊 Statistiques

- **Total de prompts** : 50
- **Secteurs couverts** : 28 industries différentes
- **Durée standard** : 20 secondes par vidéo
- **Styles visuels** : 24 variations
- **Équipement référencé** : ARRI, RED, Sony, Canon

## 🚀 Utilisation Rapide

### Avec Python

```python
import json

# Charger tous les prompts
with open('50_prompts_video_marketing_enrichis.json', 'r', encoding='utf-8') as f:
    prompts = json.load(f)

# Utiliser un prompt spécifique
prompt = prompts[0]
print(f"Secteur: {prompt['shot']['camera_system']}")
print(f"Réalisme: {prompt['visual_rules']['realism']}")
```

### Avec Node.js

```javascript
const prompts = require('./50_prompts_video_marketing_enrichis.json');

// Utiliser un prompt
const prompt = prompts[0];
console.log(`Caméra: ${prompt.shot.camera_system}`);
console.log(`Continuité: ${prompt.visual_rules.continuity}`);
```

## 📖 Documentation Complète

Pour plus d'informations sur l'utilisation des prompts avec différentes plateformes :
- **Sora 2** : https://platform.openai.com/docs/guides/video
- **Veo 3** : https://deepmind.google/models/veo/
- **Runway Gen-3** : https://runwayml.com/

## 📝 Licence

© 2025 - Collection Professionnelle de Prompts Vidéo Marketing

---

**Version** : 3.0 (Enrichie avec Réalisme et Continuité)  
**Date** : Janvier 2025  
**Format** : JSON (UTF-8)
